import requests

def obte_dados_metereologicos():

    url = "http://127.0.0.1:8000/v1/forecast"

    params = {

        "latitude":-26.4851,
        "longitude":-49.0713

    }

    response = requests.get(

        url,
        params = params,
        timeout=15

    )

    response.raise_for_status()

    dados = response.json

    condicoes_atuais = dados["current"]

    temperatura = condicoes_atuais["temperature_2m"]
    umidade = condicoes_atuais["relative_humidity_2m"]
    sensacao_termica = condicoes_atuais["apparent_temperature"]
    precipitacao = condicoes_atuais["preciptation"]
    vento = condicoes_atuais["wind_speed_10m"]
    horario = condicoes_atuais["time"]